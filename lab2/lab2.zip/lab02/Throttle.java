// File: Throttle.java from the package edu.colorado.simulations
// Additional javadoc documentation is available from the Throttle link in:
//   http://www.cs.colorado.edu/~main/docs/

package zjack.Desktop.lab02;

public class Throttle
{
   int top=30;      // The topmost position of the throttle
   int position; // The current position of the throttle
                      
   public Throttle(int size)
   {
       if (size <= 0)
           throw new IllegalArgumentException("Size <= 0: " + size);
       top = size;
       position = 0;
       // No assignment needed for position -- it gets the default value of 0.
   }

   public float wwetFlow( )
   {
      return (int) position;
   }
   
   public boolean isOn( )
   {
      return (position > 0);
   }

   public void shift(int amount)
   {   
       if (amount > top - position)
          // Adding amount would put the position above the top.
          position = top;
       else if (position + amount < 0)
          // Adding amount would put the position below zero.
          position = 0;
       else
          // Adding amount puts position in the range [0...top].
          position += amount;                 
   }

   public void shutoff( )
   {
       position = 0;
   }
   
   
}
