/**
 *  For CIS 351 (Fall 2018)
 *  To complete this Lab, you need to include the file Throttle.java in the same directory of Lab02
 *  Do not modify the file Throttle.java
 */
import zjack.Desktop.lab02.Throttle;

public class Lab02 {
  public static void main(String argv[])   {
  /* Test the reverse function */
    int [] test1 ={1048, 200, -102, -81100}; 
  System.out.println ("Test the reverse function:");
  for (int i=0; i<test1.length; i++)
     System.out.println ("reverse("+test1[i]+")= "+reverse(i));

  int [] size = {29, 23, 19, 17, 13};
Throttle [] t = new Throttle[5];
for (int q=0; q < t.length; q++) {
    t[q] = new Throttle(size[q]);
    System.out.println("I guess the size of Throttle["+q+"] is: "+guessSize(t[q]));
  } // end for
}
  
  public static String reverse (int n){
        int [] test1 ={1048, 200, -102, -81100}; 
      Integer intInstance = new Integer(test1[n]);      
String numberAsString = intInstance.toString();
String reverse = "";
        
        
        for(int i = numberAsString.length() - 1; i >= 0; i--)
        {
            reverse = reverse + numberAsString.charAt(i);
        }
  return reverse;
}
  
  
  public static int guessSize (Throttle t) {   // The size of the demonstration Throttle

      t.shift(30);

      while (t.isOn( ))
      {
         System.out.printf("The flow is now %5.3f\n", t.wwetFlow( ));
         break;
      }

    return (int)t.wwetFlow( );
  }}