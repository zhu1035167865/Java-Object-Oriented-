import java.util.Scanner;
public class lab1 {
    public static void main(String args[]) {
        int N;
          int maxDivisors=1;  
          int nummax=1;     
        Scanner scanner =new Scanner(System.in);
        System.out.println("Enter the min number : ");
        int num1 =scanner.nextInt();
        System.out.println("Enter the max number : ");
        int num2 =scanner.nextInt();
          for ( N = num1;  N <= num2;  N++ ) {
              int count=0;  
              for ( int D = 1;  D <= N;  D++ ) {  
                 if ( N % D == 0 )
                    count++;
              }
              if (count > maxDivisors) {
                 maxDivisors = count;
                 nummax = N;
              }
          }
          maxDivisors=maxDivisors-1;
          System.out.println("integers between "+num1+" and " +num2);
          System.out.println("number of divisors : " + maxDivisors);
          System.out.println( "most divisors number : " + nummax);
       System.out.print("Divisors of " + nummax+ " is ");
        for (int i = 1; i <= nummax / 2; i++) {
            if (nummax % i == 0) {
                System.out.print(i + "   ,  ");
            }
        }
        scanner.close();
    }
}
   
