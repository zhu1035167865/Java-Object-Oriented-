

import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom; //  to use use randPermute
import java.util.*; 
/**
  *  * Tests for the ArrayStack and ArrayQueue classes from Morin
  *  * Tests for a Card class
  * @author
  *   Dear Grader: I forgot put my name here, please subtract some points. 
  * @version
  *   Sep-2018
 */
public class HW03 {
  
  /* Define Global constants */
    
  static final int SHORT = 4;
  static final int LONG = 13;
  static final int ALL = 52;
  
public static void main (String [] argv) { 
  
  
  // The following shows how to create a stack (and queue) via Morin's code
  // Add the line below to create an empty stack of Cards via Morin's 
  // ArrayStack<Card> stackA = new ArrayStack<Card>(Card.class);
  // Add the line below to create an empty queue of Cards via Morin's 
  // ArrayQueue<Card> queueA = new ArrayQueue<Card>(Card.class);
  
  // Initialize
  // create a standard deck of cards
  Card [] standard = new Card[ALL]; // Create a standard deck of cards 
  for (int i=0; i<ALL; i++) {       // Fill the standard deck and display      
    standard[i] = new Card(i%13,i%4); 
    standard[i].display(); // uncomment this line to show the standard deck

  } 
  System.out.println("         ");
  // create a shuffled deck of cards
  int [] randIndex = randPermute(ALL);  // Generate a random permutation of the array [0, .., ALL]
  Card [] shuffled = new Card[ALL]; // Create a shuffled deck of cards from the standard deck
  for (int i=0; i<ALL; i++) {       // Fill the shuffled deck and display      
    shuffled[i] = new Card ((randIndex[i]%13),(randIndex[i]%4)); 
     shuffled[i].display();  // uncomment this line to show the shuffled deck
  } 
  // end of initialize  
  
  // carry out the test 
  test1();
  test2(standard, shuffled, ALL, SHORT);
  test3(shuffled, standard, ALL, SHORT);
  test4(standard, shuffled, ALL, SHORT);
} // end of Main  
  


// test1 is for testing the constructor of Card class 
// and other member functions with missing implementation
// (eg. same) in the Card class  
// DO NOT MODIFY this function
  public static void test1() {
   System.out.println("\nBegin of test 1:\n");
   Card [] test1 = new Card [SHORT]; 
   
   for (int i=0; i<SHORT; i++) {
    test1[i] = new Card (i+10,i+2);
   }
   if (Card.same(test1[0],test1[1]))
     System.out.println("test1[0] and test1[1] are different.");
   else
     System.out.println("test1[0] and test1[1] are the same.");
   if (Card.same(test1[2],test1[3]))
     System.out.println("test1[2] and test1[3] are the same.");
     
   System.out.println("\nEnd of test 1:\n");
  }
  
// End of test1  
  
// Follow the instructions given in the comments to implement test2 
  public static void test2 (Card [] fulldeck1, Card [] fulldeck2, int len, int sample) {
  // len is the no of cards in fulldeck1 (and also fulldeck2, since each fulldeck has
  // the same number of cards)  
  System.out.println("\nBegin of test 2:\n");
 
  // Create an empty stack of Cards via Morin's ArrayStack class
  ArrayStack<Card> t1 = new ArrayStack<Card>(Card.class);
  // Create an empty queue of Cards via Morin's ArrayQueue class
    ArrayQueue<Card> tt2 = new ArrayQueue<Card>(Card.class);
  // push the Cards fulldeck[0], ... , fulldeck[sample-1] to an empty stack
 for(int i=0;i<fulldeck1.length;i++){
     t1.add(fulldeck1[i]);}
Iterator<Card>iit1=t1.iterator();
   while (iit1.hasNext()){
     iit1.next().display();}
   
  // enqueue the Card fulldeck[0], ... , fulldeck[sample-1] to an empty queue
    for(int i=0;i<fulldeck2.length;i++){
     tt2.add(fulldeck2[i]);}
    System.out.println();
 Iterator<Card>pt2=tt2.iterator();
   while (pt2.hasNext()){
     pt2.next().display();}
  // print something like
  // "Display a sample of the first stack of cards from top to bottom:"
  // when displaying the stack and queue in the steps below 
  
  // Display the stack of cards formed from top to bottom
  // Display the queue of cards formed from front to end 
   
  // Repeat the same procedure above from the deck fulldeck2    
  System.out.println("\nEnd of test 2.\n");
  }
  
  public static void test3 (Card [] fulldeck1, Card [] fulldeck2, int len, int sample){
 System.out.println("\nBegin of test 3:\n");
  
   ArrayQueue<Card>r1= new ArrayQueue<Card>(Card.class);
   ArrayQueue<Card>r2= new ArrayQueue<Card>(Card.class);
   for(int i=0;i<fulldeck1.length;i++){
     r1.add(fulldeck1[i]);
   }
   for(int w=0;w<fulldeck2.length;w++){
     r2.add(fulldeck2[w]);
   }
   
   for(int q=r1.size();q>0;q--){
     if(r1.peek().getRank()<10&&r1.peek().getRank()>0){
       r1.remove();}
     else{
       r1.add(r1.remove());
     }
   }
    for(int q=r2.size();q>0;q--){
      if(r2.peek().getRank()!=0){
       r2.remove();}
     else{
       r2.add(r2.remove());
     }
   }
  
  // Create q1, an empty queue of Cards via Morin's ArrayQueue class
  // Create q2, an empty queue of Cards via Morin's ArrayQueue class  
  // put fulldeck1 into q1 in the same order  
  // put fulldeck2 into q2 in the same order
  // Remove all the non-face cards from q1
  // keep only the face cards (JACK, QUEEN, KING only) with suit ace in q1, maintain the original order
  // keep only the aces in q2, maintain the original order
  // display q1, from front to end, with the given heading
   System.out.println("*** Display q1 ***");
   Iterator<Card>it1=r1.iterator();
   while (it1.hasNext()){
     (it1.next()).display();}
   // ADD code here
  // display q2, from front to end, with the given heading
   System.out.println("*** Display q2 ***");
   // ADD code here
   Iterator<Card>it2=r2.iterator();
   while (it2.hasNext()){
     (it2.next()).display();}
  System.out.println("\nend of test 3:\n");
  
  }
  
  public static void test4 (Card [] fulldeck1, Card [] fulldeck2, int len, int sample){
   System.out.println("\nBegin of test 4: part 1\n");
   
   ArrayStack<Card>s1= new ArrayStack<Card>(Card.class);
ArrayStack<Card>s2= new ArrayStack<Card>(Card.class);
ArrayStack<Card>s3= new ArrayStack<Card>(Card.class);
ArrayStack<Card>s4= new ArrayStack<Card>(Card.class);
for(int r=0;r<fulldeck1.length;r++){
  if(r%4==0){
    s1.add(fulldeck1[r]);
    }
  if(r%4==1){
    s2.add(fulldeck1[r]);
  }
  if(r%4==2){  
  s3.add(fulldeck1[r]);
  }
  if(r%4==3){  
  s4.add(fulldeck1[r]);
  }
}

  // Create s1, an empty stack of Cards via Morin's ArrayStack class
  // Create s2, an empty stack of Cards via Morin's ArrayStack class 
  // Create s3, an empty stack of Cards via Morin's ArrayStack class  
  // Create s4, an empty stack of Cards via Morin's ArrayStack class  
  
  // Distribute the cards in fulldeck1 to s1, s2, s3, s4 in the round robin fashion 
  // `push' each card on the top of the corresponding stack 
  // when it is done, show the top card from each stack in the order s1, s2, s3, s4 
   
  // ADD code here 

  
   System.out.print("\nThe top card from stack s1 is: ");
   (s1.get(s1.size()-1)).display();
  // ADD code here
   
   System.out.print("\nThe top card from stack s2 is: ");
(s2.get(s2.size()-1)).display();
   // ADD code here
   
   System.out.print("\nThe top card from stack s3 is: ");
(s3.get(s3.size()-1)).display();
   // ADD code here
   
   System.out.print("\nThe top card from stack s4 is: ");
(s4.get(s4.size()-1)).display();
   // ADD code here
  
   System.out.println ("\n End of test 4: part 1\n");
   System.out.println ("\n Begin of test 4: part 2\n");
  
  // Repeat the same procedure for the fulldeck2. That is:
  // Reset s1, s2, s3 and s4 to empty stacks of Cards via Morin's ArrayStack class
   
  // Distribute the cards in fulldeck2 to s1, s2, s3, s4 in the round robin fashion 
  // `push' each card on the top of the corresponding stack 
  // when it is done, show the top card from each stack in the order s1, s2, s3, s4 
   // ADD code here
   for(int r=0;r<fulldeck2.length;r++){
  if(r%4==0){
    s1.add(fulldeck2[r]);
    }
  if(r%4==1){
    s2.add(fulldeck2[r]);
  }
  if(r%4==2){  
  s3.add(fulldeck2[r]);
  }
  if(r%4==3){  
  s4.add(fulldeck2[r]);
  }
}

  
   System.out.print("\nThe top card from stack s1 is: ");
   (s1.get(s1.size()-1)).display();
   // ADD code here
   
   System.out.print("\nThe top card from stack s2 is: ");
  (s2.get(s2.size()-1)).display();
   // ADD code here
   
   System.out.print("\nThe top card from stack s3 is: ");
  (s3.get(s3.size()-1)).display();
   // ADD code here
   
   System.out.print("\nThe top card from stack s4 is: ");
(s4.get(s4.size()-1)).display();
   // ADD code here

   System.out.println("\nEnd of test 4: part 2\n");
   System.out.println("\nEnd of test 4.\n");
   
} // end test4


// DO NOT MODIFY THE CODE BELOW
  
public static int [] randPermute (int n) {
// n must be non-negative
int [] answer = new int[n];
for (int i=0; i<n; i++)
 answer[i] =i;
int len = n;
while (len > 1){
  swap(answer, getRandomIndex(0,len-1),len-1);
  len--;} // end while
return answer;
} // end of randPermute

public static void swap(int [] a, int s, int t) {//  0<=s<=t<a.length
  int temp = -1;
  temp = a[s];
  a[s] = a[t];
  a[t] = temp;
} // end of swap
public static int getRandomIndex(int r, int s){ // requires 0 <= r <= s 
// needs to add the line import java.util.concurrent.ThreadLocalRandom;
   return ThreadLocalRandom.current().nextInt(r, s + 1);
} // end getRandomIndex


} // end of Class HW03