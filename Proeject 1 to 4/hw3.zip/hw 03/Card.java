/** 
 * File: Card.java
 * This is part of HW03 for the class CIS 351 (Fall 2018)
 * @ author
 * I forgot to add my name, so please take off some points
 * @ version
 * Sep 11, 2018
 **/

// DO NOT MODIFY the following import statement
import java.util.concurrent.ThreadLocalRandom;  // for the function myRandInt

/* Instructions:
 * Follow the guidelines given in the comments, complete the implementation
 * of the Card class 
**/

public class Card {
    private final int rank; // the rank of the Card
    private final int suit; // the suit of the Card
 
 /**
 *  Construct a valid playing Card 
 * @param aRank
 *  the rank of the Card  
 * @param aSuit
 *  the suit of the Card
 * precondition
 *  aRank must be in the range from 0 to 12 (both inclusive)
 *  aSuit must be in the range from 0 to 3 (both inclusive)
 * postcondition
 *  The Card has been initialized with a valid rank and a valid suit
 * @exception IllegalArgumentException
 *  Indicates that rank is outside the given range when applicable 
 *  Indicates that suit is outside the given range when applicable 
 **/
public static final String[] RANKS = {
         "Ace", "2", "3", "4", "5", "6", "7",
        "8", "9", "10", "Jack", "Queen", "King"};

    // string representations of suits
    public static final String[] SUITS = {
        "Clubs", "Diamonds", "Hearts", "Spades"};
    

public Card (int aRank, int aSuit) throws IllegalArgumentException { 
 if (aRank < 0) {
            throw new IllegalArgumentException("Invalid rank");
        }
        if (aSuit < 0) {
            throw new IllegalArgumentException("Invalid suit");
        }
        rank = aRank;
        suit = aSuit;
}
   
 /** 
  * constructor which assign valid rank and suit in a
  * `random' manner, using the function myRandInt
  *
  **/

 
 public Card () {
  rank = myRandInt(0,12);
  suit = myRandInt(0,3);  
 }
 
  /** 
   * A getter function 
   * @return
   * the suit of the Card
   **/
 
 public int getSuit(){
 return suit; // change this to return the suit of the given card      
 }
 
 /** 
  * A getter function 
  * @return
  * the rank of the Card
  **/
 
 public int getRank(){
 return rank; // change this to return the suit of the given card 
 }
 
 /**
  * Display the Card
  * postcondition :
  * the rank and the suit of the Card are displayed to screen,
  * for example: ACES / SPADES
  **/
 
 public void display(){
   
  System.out.println(RANKS[rank] + " of " + SUITS[suit]);
    
  }
 
  /**
   * @param
   * c1 is a Card
   * @param
   * c2 is a Card
   * preconditions:
   * first must be non-negative and first must be less than or equal to last  
   * @return
   * an int randomly chosen from first (inclusive) to last  (inclusive) 
   * 
   * needs to add the line import java.util.concurrent.ThreadLocalRandom;
   **/
 
 public static boolean same (Card c1, Card c2) {
    return (c1.suit == c2.suit && c1.rank == c2.rank);
 }
  
 /**
  * @param first
  * an int, the beginning of the range (inclusive)
  * @param last
  * an int, the end of the range (inclusive)
  * @precondition
  * 0 <= first <= last 
  * @return 
  * an int randomly chosen from first (inclusive) to last  (inclusive) 
  * @require 
  * needs to add the line import java.util.concurrent.ThreadLocalRandom;
  **/
 // DO NOT MODIFY THIS FUNCTION
 private int myRandInt(int first, int last){ 
     return ThreadLocalRandom.current().nextInt(first, last + 1);
 } // end myRandInt
} // end class Card
