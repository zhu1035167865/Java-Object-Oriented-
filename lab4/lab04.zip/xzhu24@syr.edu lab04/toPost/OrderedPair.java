/**
 * Java Code for Lab 4
 */


public class OrderedPair<T> implements Pairable {
  
  private T first, second;  // Data: the ordered pair is (first, second)
  
  /* Member functions */

  public OrderedPair(T item1, T item2)  { // Fill in the required code and comment
  first = item1;
   second = item2;
  }
  public T getFirst(){
    return first; // Replace this line and fill in the required code and comment
  }
  public T getSecond(){
    return second; // Replace this line and fill in the required code and comment
  }
  public void swap(){ // Fill in the required code and comment
     T temp = first;
      first = second;
      second = temp;
  }
  
  public static void main (String [] argv){
    
    System.out.println("Problem A");
  for(int i=0;i<=9;++i) {
            for(int j=0;j<=9;j++) {
               OrderedPair<Integer> x= new OrderedPair<Integer>(i,j);
              System.out.print("["+x.first+","+x.second+"]  ");
            }
            System.out.println();
        }
  System.out.println("Problem B");
  for(int i=0;i<=9;++i) {
            for(int j=1;j<=9;j++) {
              OrderedPair<Integer> x= new OrderedPair<Integer>(i,j);
             if(i < j)
                      {
                       System.out.print("["+x.first+","+x.second+"]  ");
                      }
                      else
                      {
                          System.out.print("       ");
                      }
                   }
                   System.out.println("");
                 }
        
  System.out.println("Problem C");
  for(int i=0;i<=9;++i) {
            for(int j=0;j<=i;j++) {
              OrderedPair<Integer> x= new OrderedPair<Integer>(i,j);
              System.out.print("["+x.first+","+x.second+"]  ");
            }
            System.out.println();
  } 
  }}