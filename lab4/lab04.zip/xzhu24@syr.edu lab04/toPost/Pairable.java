public interface Pairable<T>
{
  public T getFirst();
  public T getSecond();
  public void swap();
} // end Pairable 

