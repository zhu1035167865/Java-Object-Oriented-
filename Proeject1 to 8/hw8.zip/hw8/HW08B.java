/**
 * Fall 2018 
 * CIS 351
 * Part of Homework 8
 * Name:
 * Email:
 */
public class HW08B {
  class Job { // denoted as [d,p] in the description of HW 8
int d; // job id
int p; // job priority
} 
  /* Main function */
  
  public static void main (String [] argv){
  task1();
  task2();
  }
  public static void task1(){
    System.out.println("HW8B, Task 1\n");
   int i = 0;
   int []a= new int[10];
   for(int q=0;q<10;q++){
   int w=RandEx.getRandomIndex(1,500);
   a[q]=w;
   }
  for (i = 0; i < 10; i++) {
   for (int j = i; j < 10; j++) {
             
     System.out.print("["+a[j]+","+j+"]");
   }
   System.out.println();
  }

    System.out.println("End of Task 1\n");     
  }
  public static void task2(){
    System.out.println("HW8B, Task 2\n");
    int []r= new int[11];
   for(int q=0;q<=10;q++){
   int e=RandEx.getRandomIndex(1,500);
   r[q]=e;
   }
    for(int i=1;i<11;++i)
{
for(int j=1;j<=i;++j)
System.out.print("["+r[j]+","+j+"]");
System.out.println();
}
    
    System.out.println("End of Task 2\n");
  }
}