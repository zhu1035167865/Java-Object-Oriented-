/**
 * Auto Generated Java Class.
 */
import java.util.*;
import java.io.*;
import java.util.Random;
public class HW07 {
  /* Following the instructions given in the homework description,
   * complete the tasks by filling in the required details as listed below.
   */
  public static int [] array1=new int [105];
  public  static int [] array2= new int [5];
  public static void main (String [] argv){    
    task1();
    task2();
    task3();
    task4();
    task5();
  }
  public static void task1(){
    System.out.println("Begin of task 1\n");
    
    // 1. Create H1
   ChainedTable H1 =new ChainedTable(105);
    
    // 2. Create array A1 and put 105 distinct integers 
    // , say, a_1, ... , a_105 from U to A1
for (int a = 0; a < array1.length; a++) {
    array1[a] = (a + 1) ;
}
for (int a = 0; a < array1.length-5; a++) {
    array1[a] = (a + 1) ;
    array1=RandEx.randPermute(array1.length);
    H1.put(array1[a],a);
}
System.out.println();
array1=RandEx.randPermute(array1.length);
for (int i =0;i<array2.length;i++){
array2[i]=array1[i];
}
System.out.println();
for(int i =0;i<5;i++){
  System.out.print("is H1 contaions key b"+(i+1)+" "+array2[i]+"?          ");
  boolean yes=true;
  if(H1.containsKey(array2[i])==yes){
    System.out.println("Yes");
  }
  else {System.out.println("NOT");
}
}
for(int i =100;i<105;i++){
  System.out.print("is H1 contaions key a"+(i+1)+"  "+array1[i]+"?          ");
  boolean yes=true;
  if(H1.containsKey(array1[i])==yes){
    System.out.println("Yes");
  }
  else {System.out.println("NOT");
}
}
    // 3. Randomly select b1, ... , b5 from a_1 to a_100
    //    Print b_1, .. , b_5 in the form B=[b_1, ... , b_5]  
    
    
    
    
    // 4. Use containskey function to answer the questions (see HW description)
    //    print the answers to screen
    //    e.g. b_1 = 144 a_101 = 231. The answers will be shown like:
    // 
    //    H1 contains 144?    YES
    //    H1 contains 231?    NO
    
    
    System.out.println("\nEnd of Task 1\n");
    
  }
  public static void task2(){
    System.out.println("Begin of Task 2\n");
    // 1. Create H2
   ChainedTable H2 =new ChainedTable(105);
   for (int a = 0; a < array1.length; a++) {
    array1[a] = (a + 1) ;
    array1=RandEx.randPermute(array1.length);
    H2.put(array1[a],a);
}
   System.out.println();
array1=RandEx.randPermute(array1.length);
for (int i =0;i<array2.length;i++){
array2[i]=array1[i];
}
   for(int i =0;i<5;i++){
    H2.remove(array2[i]);
   }
   array1=RandEx.randPermute(array1.length);
   for(int i =0;i<5;i++){
    System.out.print("remove d"+i+" from H2" );
    if (H2.get(array1[i])==null){
   System.out.println("   yes   "+H2.get(array1[i]));
    }
    else {
   System.out.println("    not    " +H2.get(array1[i])); 
    }
   }
    // 2. Create array C1 and put 105 distinct integers 
    // , say, c_1, ... , c_105 from U to C1
    
    
    
    // 3. Randomly select d1, ... , d5 from c_1 to c_100
    //    Print d_1, .. , d_5 in the form D=[d_1, ... , d_5]  
    
    
    
    
    // 4. Use removes and get function to answer the questions (see HW description)
    //    print the answers to screen
    //    e.g. d_1 = 144 c_101 = 231. The answers will be shown like:
    // 
    //    Action                Return null?           Element return is:   
    //    Remove 144 from H2    ...                    ... 
    //    Remove 231 from H2    ...                    ... 
    //    etc.
    System.out.println("\nEnd of Task 2\n");
  }
  public static void task3(){
    System.out.println("Begin of Task 3\n");
    // AFTER you have completed your implementation of the maxChainLength
    // length function, do the following:
    
    // 1. Create an empty (hash table H3, Insert the elements from 0 to 
    // table.length-1, compute maxChainLength of H3 
    // Show to the screen
    // Max. Chain length of H3 =  ...
    ChainedTable H3= new ChainedTable(5);
    H3.put(111,1);
    H3.put(111,2);
    System.out.println("H3 LENGTH = " +H3.maxChainLength());
    
    // 2. Create an empty hash table H4, Insert the elements p, 2p, 10p 
    // (element i = i*p and p is table.length) compute maxChainLength of H4 
    // Show to the screen
    // After inserting element 1, Max. Chain length of H4 =  ...
    // After inserting element 2, Max. Chain length of H4 =  ...
    // ...
    // After inserting element 10, Max. Chain length of H4 =  ...
    ChainedTable H4= new ChainedTable(10);
    for (int a = 0; a < 10; a++) {
    array1[a] = (a + 1) ;
    array1=RandEx.randPermute(array1.length);
    H4.put(array1[a],a);
}
    System.out.println("H4 LENGTH = " +H4.maxChainLength());
    
    System.out.println("End of Task 3\n");
  }
  public static void task4(){
    System.out.println("Begin of Task 4\n");
    // 1. Create an empty hash table H5
    
    ChainedTable H5= new ChainedTable(10000);
    int [] array3= new int [1000];
    for(int a =0; a<array3.length;a++){
    array3[a]=a+1;
      array3=RandEx.randPermute(array3.length);
  H5.put(array3[a],a);
    }
    for(int a =0; a<array3.length;a++){
    array3[a]=a+1;
      array3=RandEx.randPermute(array3.length);
  H5.put(array3[a],a);
    }
    for(int a =0; a<array3.length;a++){
    array3[a]=a+1;
      array3=RandEx.randPermute(array3.length);
  H5.put(array3[a],a);
    }
    for(int a =0; a<array3.length;a++){
    array3[a]=a+1;
      array3=RandEx.randPermute(array3.length);
  H5.put(array3[a],a);
    }
    for(int a =0; a<array3.length;a++){
    array3[a]=a+1;
      array3=RandEx.randPermute(array3.length);
  H5.put(array3[a],a);
    }
    for(int a =0; a<array3.length;a++){
    array3[a]=a+1;
      array3=RandEx.randPermute(array3.length);
  H5.put(array3[a],a);
    }
    for(int a =0; a<array3.length;a++){
    array3[a]=a+1;
      array3=RandEx.randPermute(array3.length);
  H5.put(array3[a],a);
    }
    for(int a =0; a<array3.length;a++){
    array3[a]=a+1;
      array3=RandEx.randPermute(array3.length);
  H5.put(array3[a],a);
    }
    for(int a =0; a<array3.length;a++){
    array3[a]=a+1;
      array3=RandEx.randPermute(array3.length);
  H5.put(array3[a],a);
    }
    for(int a =0; a<array3.length;a++){
    array3[a]=a+1;
      array3=RandEx.randPermute(array3.length);
  H5.put(array3[a],a);
    }
    System.out.println("value l = "+H5.maxChainLength()/10);
    // 2. Insert 1000 elements to H5, call t1, ... , t1000
    // The elements are selected randomly from 0 to Integer.MAX_VALUE        
    // 3. Use put function to insert t1, ... , t1000 to H5. Compute 
    // maxChainLength of H5. 
    // 4. Repeat step 2 and 3 10 times and compute the average, Call L.
    
    
    
    
    
    
    // 5.
    // Show L to the screen by printing
    // The average value L = ....
     
    System.out.println("\nEnd of Task 4\n");
  }
  public static void task5(){
    System.out.println("Begin of Task 5\n");
    
    // 1. Select 1000 distinct integers randomly from U, 
    // call them u1, ... , u1000
    
   int sum=0;
   int [] array7= new int [1000];
    for(int a =0; a<29;a++){
    array7[a]=a+1;
      array7=RandEx.randPermute(array7.length);
  sum=array7[a]+sum;
    }
    System.out.println("value l = "+sum/29);
    
    
    
    // 2.
    // use u1, ..., u1000 to
    // Conduct the experiment for p = 29
    // Show results to the screen by printing
    // For p = 29, The value L = ...
       sum=0;
   int [] array8= new int [1000];
    for(int a =0; a<30;a++){
    array8[a]=a+1;
      array8=RandEx.randPermute(array8.length);
  sum=array8[a]+sum;
    }
    System.out.println("value l = "+sum/30);
    
    
    
    // 3.
    // use u1, ..., u1000 to
    // Conduct the experiment for p = 30
    // Show results to the screen by printing
    // For p = 30, The value L = ...
    sum=0;
   int [] array9= new int [1000];
    for(int a =0; a<30;a++){
    array9[a]=a+1;
      array9=RandEx.randPermute(array9.length);
  sum=array9[a]+sum;
    }
    System.out.println("value l = "+sum/31);
    
    
    
    // 4.
    // use u1, ..., u1000 to
    // Conduct the experiment for p = 31
    // Show results to the screen by printing
    // For p = 31, The value L = ...
    
   sum=0;
   int [] array0= new int [1000];
    for(int a =0; a<30;a++){
    array0[a]=a+1;
      array0=RandEx.randPermute(array0.length);
  sum=array0[a]+sum;
    }
    System.out.println("value l = "+sum/32);
    
    
    
    // 5.
    // use u1, ..., u1000 to
    // Conduct the experiment for p = 32
    // Show results to the screen by printing
    // For p = 32, The value L = ...
    
    
    System.out.println("\nEnd of Task 5\n");
  }
}