/** 
 *  Filename: Sample2.java
 */ 

class Sample2 {
  public static void main (String[] argv) {
    // read in three doubles (distinct) of your choice
    // for example, let x be 1.0, y be 2.0, and z be 3.0; 
    double x=1.0;
    double y=4.0;
    double z=3.0;
    
    // add code here to print your lastname followed by a comma and then your firstname
    System.out.println("Xiongfeng,Zhu");
    
    // add code here to print the section number of the lecture you've registered.
   System.out.println("CIS 351 M004");
    
    // Display the three doubles of your choice
    System.out.println(x);
     System.out.println(y);
      System.out.println(z);
      double p=middleOfThree(x,y,z);
       System.out.println("middle number : ");
      System.out.println(p);
    // Display the middle of the three doubles of your choice
  }
 ////////////////////////////////////////////////////////////////
  
  public static double middleOfThree(double a, double b, double c) {
      double min = a, max =a;
    if( b < min )
        min = b;
    else
        max = b;

    if( c < min )
        min = c;
    else if( c > max )
        max = c;

    return a + b + c - min - max;
  }}
