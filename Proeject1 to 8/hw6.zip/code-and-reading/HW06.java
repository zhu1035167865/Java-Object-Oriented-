/**
 * CIS 351 Fall 2018 
 * HW 06
 * 
 * Name:
 * Email:
 * 
 * 
 * Follow the HW 06 description to complete the code
 */
public class HW06 {
  
  /* Main function */
  
  public static void main (String [] argv) {
  task1();
  task2();
  task3();
  task4();
  }
  
  public static void task1() {
  System.out.println("Task 1\n");
     IntBTNode root = new IntBTNode(15,null,null);
     IntBTNode root3 = new IntBTNode(15,null,null);

   System.out.println(" ");
      root.insert1(6);
       root.insert1(18);
        root.insert1(3);
         root.insert1(7);
          root.insert1(17);
           root.insert1(20);
            root.insert1(2);
             root.insert1(4);
              root.insert1(13);
               root.insert1(9);
               root.insert1(6);
       root3.insert(18);
        root3.insert(3);
         root3.insert(7);
          root3.insert(17);
           root3.insert(20);
            root3.insert(2);
             root3.insert(4);
              root3.insert(13);
               root3.insert(9);
               System.out.println(IntBTNode.height(root)-7);
  // Fill in the required code
  System.out.println("An in-order listing of the nodes in the tree Ta:\n");
   root.inorderPrint();
   System.out.println();
  // Fill in the required code
  System.out.println("A breadth first listing of the nodes in the tree Ta:\n");
  // Fill in the required code
root3.inorderPrint();
  System.out.println("End of Task 1\n");
  }
  
  
  public static void task2() {
  System.out.println("Task 2\n");
  int array[]  = new int[20];
  array[0]=1;
   array[1]=2;
    array[2]=3;
     array[3]=4;
      array[4]=5;
       array[5]=6;
        array[6]=7;
         array[7]=8;
          array[8]=9;
           array[9]=10;
            array[10]=11;
             array[11]=12;
              array[12]=13;
               array[13]=14;
                array[14]=15;
                 array[15]=16;
                  array[16]=17;
                   array[17]=18;
                    array[18]=19;
                     array[19]=20;
array=RandEx.randPermute(array.length);
 IntBTNode root1 = new IntBTNode(array[0],null,null);
 IntBTNode root4 = new IntBTNode(array[0],null,null);
for(int i=1;i<20;i++){
root1.insert1(array[i]+1);  }
  for(int i=1;i<20;i++){
root4.insert(array[i]+1);  }
  System.out.println("The random permutation P1 is :\n");
  // Fill in the required code
  root1.inorderPrint();
  System.out.println("An in-order listing of the nodes in T2 :\n");
   root4.inorderPrint();
  // Fill in the required code
  
  
  System.out.println("A breadth first listing of the nodes in T2 :\n");
  
  // Fill in the required code
  
  System.out.println("End of Task 2\n");
  }
   
  public static void task3() {
  System.out.println("Task 3\n");
  // Fill in the required code
    int array1[]  = new int[30];
     array1[0]=1;
   array1[1]=2;
    array1[2]=3;
     array1[3]=4;
      array1[4]=5;
       array1[5]=6;
        array1[6]=7;
         array1[7]=8;
          array1[8]=9;
           array1[9]=10;
            array1[10]=11;
             array1[11]=12;
              array1[12]=13;
               array1[13]=14;
                array1[14]=15;
                 array1[15]=16;
                  array1[16]=17;
                   array1[17]=18;
                    array1[18]=19;
                     array1[19]=20;
                     array1[20]=21;
                     array1[21]=22;
                     array1[22]=23;
                     array1[23]=24;
                     array1[24]=25;
                     array1[25]=26;
                     array1[26]=27;
                     array1[27]=28;
                     array1[28]=29;
                     array1[29]=30;
    array1=RandEx.randPermute(array1.length);
     IntBTNode root2 = new IntBTNode(array1[0],null,null);
     IntBTNode root5 = new IntBTNode(array1[0],null,null);
for(int i=1;i<30;i++){
  root2.insert1(array1[i]+1);}
  System.out.println("The random permutation P2 is:\n");
 root2.find(root2,3).bftraverse();
 System.out.println();
 for(int i=1;i<20;i++){
root5.insert(array1[i]+1);  }
   // Fill in the required code
    root2.inorderPrint();
  System.out.println("The random permutation P3 is:\n");
  // Fill in the required code 
  root5.inorderPrint();
  System.out.println("The results of finding elements from P3 in the Tree are:\n");
  // Fill in the required code 
   for(int i=0;i<30;i++){
    if(array1[i]==-5||array1[i]==-4||array1[i]==-3||array1[i]==-2||array1[i]==-1||array1[i]==0||array1[i]==1||array1[i]==2||array1[i]==3||array1[i]==4||array1[i]==5){
      System.out.print(" "+i);}
  }
  System.out.println("End of Task 3\n");
  }
   
  public static void task4() {
  System.out.println("Task 4\n");
  System.out.println("Experiment starts\n");
  // Fill in your code
  int [] array5 = new int[1000];
for (int a = 0; a < array5.length; a++) {
    array5[a] = (a + 1) ;
}

   double tol =0;
  IntBTNode root6 = new IntBTNode(array5[0],null,null);
 array5=RandEx.randPermute(array5.length);
 for(int i=0;i<9;i++){
   for(int a=2;a<=10;a++){
     System.out.print(" "+array5[a]);
   root6.insert1(array5[a]);
   }
    array5=RandEx.randPermute(array5.length);
     tol = tol+(IntBTNode.height(root6))%11;
    System.out.println();
   }
  System.out.println("The Results (Step e in task 4) are displayed below\n");
  // Fill in the required code
System.out.println(tol/10);
  System.out.println("End of Task 4\n");
  }
}
