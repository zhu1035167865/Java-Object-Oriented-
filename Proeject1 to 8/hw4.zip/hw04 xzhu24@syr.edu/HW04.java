/**
 * HW04 for CIS 351, Fall 2018
 */
import java.util.concurrent.ThreadLocalRandom;
public class HW04 {
  
  /* main function */
  
  public static void main (String [] argv){
    System.out.println("////////////////");
    test1();
    System.out.println("////////////////");
    test2();
    System.out.println("////////////////");
    test3();
    System.out.println("////////////////");
    test4();
    System.out.println("////////////////");
    test5();
    System.out.println("////////////////");
  }
////////////////////////////////////////////////////
// test 1
  public static void test1 () {
    
    System.out.println("\ntest 1 begins\n");
    // purpose: test the constructors, toString function
    // and the size function
    // 1. create an empty set S11
    // Show the empty set S11
    
    IntSet A11 = new IntSet();
    System.out.println("\nArray A11 is :" + A11.toString());
    
    IntSet S11 = new IntSet();
    System.out.println("\nSet S11 is :" + S11.toString());
    System.out.println("\nSet Size of S11 is :" + S11.size());
    
    IntSet A12 = new IntSet(3,2,1);
    System.out.println("\nArray A12 is :" + A12.toString());
    
    IntSet S12 = new IntSet(3,2,1);
    System.out.println("\nSet S12 is :" + S12.toString());
    System.out.println("\nSet Size of S12 is :" + S12.size());
    
    
    int [] Array13 = getRandomArray(7,5,9);
    IntSet A13 = new IntSet(Array13);
    System.out.println("\nArray 13 is :" + A13.toString());
    
    IntSet S13 = new IntSet(Array13);
    System.out.println("\nSet S13 is :" + S13.toString());
    System.out.println("\nSet Size of S13 is :" + S13.size());
    
    System.out.println("\nEnd of test 1\n");
  }
// End of test 1  
////////////////////////////////////////////////////  
// test 2
  public static void test2 () {
    System.out.println("\ntest 2 begins\n");
    // purpose Test the add function, remove function and
    // their combinations
    
    int [] Array21 = {1,2,3};
    IntSet A21 = new IntSet(Array21);
    System.out.println("\nArray A21 is :" + A21.toString());
    
    IntSet S21 = new IntSet();
    for (int i=0; i<Array21.length; i++)
      S21.add(Array21[i]);
    System.out.println("\nSet S21 is :" + S21.toString());
    
     
    int [] Array22 = {6,6,7,7,9,9};
    IntSet A22 = new IntSet(Array22);
    System.out.println("\nArray A22 is :" + A22.toString());
    
    IntSet S22 = new IntSet();
    for (int i=0; i<Array22.length; i++)
      S22.add(Array22[i]);
    System.out.println("\nSet S22 is :" + S22.toString());
    
    int [] Array23 = getRandomArray(7,12,18);
    IntSet A23 = new IntSet(Array23);
    System.out.println("\nArray A23 is :" + A23.toString());
    
    IntSet S23 = new IntSet();
    for (int i=0; i<7; i++)
      S23.add(Array23[i]);
    System.out.println("\nSet S23 is :" + S23.toString());
    
    
    int [] Array24 = getRandomArray(7,15,21);
    IntSet A24 = new IntSet(Array24);
    System.out.println("\nArray A24 is :" + A24.toString());
    
    IntSet S24 = new IntSet(Array24);
    System.out.println("\nSet S24 is :" + S24.toString());
    for (int i=0; i<7; i++)
      S23.remove(Array24[i]);
    System.out.println("\nAfter removing elements from S24 (created via A24), S23 is :" + S23.toString());
    
    
    
    int [] Array25 = getRandomArray(7,15,21);
    IntSet A25 = new IntSet(Array25);
    System.out.println("\nArray A25 is :" + A25.toString());
    
    IntSet S25 = new IntSet(Array25);
    System.out.println("\nSet S25 is :" + S25.toString());
    for (int i=0; i<5; i++){
      int pos = getRandomInt(0,6);
      System.out.println("attempt to remove Array25["+pos+"]= "+Array25[pos]+" for S25");
      S25.remove(Array25[pos]);
    }
    System.out.println("\nAfter these attempts, S25 is :" + S25.toString());
    
    System.out.println("\nEnd of test 2\n");
  }
// End of test 2   
////////////////////////////////////////////////////
// test 3
  public static void test3 () {
    System.out.println("\ntest 3 begins\n");
    // purpose: test the contains function
    
    int [] Array31 = getRandomArray(7,24,30);
    IntSet A31 = new IntSet(Array31);
    System.out.println("\nArray A31 is :" + A31.toString());
    
    IntSet S31 = new IntSet(Array31);
    System.out.println("\nSet S31 is :" + S31.toString());
    
    for (int i=0; i<10; i++){
      System.out.println("S31 contains "+(i+23)+"? "+ S31.contains(i+23));
    }
    
    
    System.out.println("\nEnd of test 3\n");
  }
// End of test 3   
////////////////////////////////////////////////////
// test 4
  public static void test4 () {
    System.out.println("\ntest 4 begins\n");
    // purpose test the equals function
    
    int [] Array41 = getRandomArray(7,31,34);
    IntSet A41 = new IntSet(Array41);
    System.out.println("\nArray A41 is :" + A41.toString());
    
    IntSet S41 = new IntSet(Array41);
    System.out.println("\nSet S41 is :" + S41.toString());
    
 
      System.out.println("S41 equals "+S41.toString()+"? "+S41.equals(S41));  
      for (int i=0; i<5; i++) {
        IntSet S42 = new IntSet(Array41);
        S42.add(i+31);
        System.out.println("S41 equals "+S42.toString()+"? "+S41.equals(S42));  
        System.out.println(S42.toString()+ " equals "+ S41.toString()+ " ? " + S42.equals(S41));  
      }
      
    
    System.out.println("\nEnd of test 4\n");
  }
// End of test 4
////////////////////////////////////////////////////
// test 5
  public static void test5 () {
    System.out.println("\ntest 5 begins\n");
    // purpose to test set union operations
    
     
    int [] Array51 = getRandomArray(7,35,39);
    int [] Array52 = getRandomArray(7,37,41);
    IntSet A51 = new IntSet(Array51);
    System.out.println("\nArray A51 is :" + A51.toString());
    
    IntSet S51 = new IntSet(Array51);
    System.out.println("\nSet S51 is :" + S51.toString());
    
    IntSet A52 = new IntSet(Array52);
    System.out.println("\nArray A52 is :" + A52.toString());
    
    IntSet S52 = new IntSet(Array52);
    System.out.println("\nSet S52 is :" + S52.toString());
    
    System.out.println("\nArray S51 U S52 is :" + (IntSet.union(S51,S52)).toString());
    
    System.out.println("\nEnd of test 5\n");
  }
// End of test 5
////////////////////////////////////////////////////

////////////////////////////////////////////////////
//  General random numbers (type int) and arrays (type int [])
  public static int [] getRandomArray(int length, int low, int high){
    int [] ans = new int[length];
    for (int i=0; i<length; i++)
      ans[i] = getRandomInt(low,high);
     return ans; 
  }
  
  public static int getRandomInt(int r, int s){ // requires 0 <= r <= s 
// needs to add the line import java.util.concurrent.ThreadLocalRandom;
   return ThreadLocalRandom.current().nextInt(r, s + 1);
  } // end getRandomIndex

////////////////////////////////////////////////////
}