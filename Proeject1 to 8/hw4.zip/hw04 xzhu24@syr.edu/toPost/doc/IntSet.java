// Based on NumList.java which based roughly on Morin's SLList.java
import java.util.Iterator;
import java.util.NoSuchElementException;
import javax.management.InstanceNotFoundException;

public class IntSet {
  
  ////////////////////////////////////////////////////////////////////
  /** The internal Node class */
  class Node {
    int val;
    Node next;
    // constructors    
    public Node(int v, Node nxt) {
      val = v; next = nxt;
    }
    public Node() { 
      this(0, null); 
    }
  }
  ////////////////////////////////////////////////////////////////////
  
  /** Front of the list */
  Node head;
  /** Tail of the list */
  Node tail;
  /** The number of elements in the list */
  int n;
  
  ////////////////////////////////////////////////////////////////////  
  /**
   * Construct an empty list to represent an empty set
   */
  public IntSet() {  
    head = tail = null;
    n = 0;
  }
  
  /**
   * Constructor that builds a set from argument ints. 
   * E.g.:  new IntSet(1,1,2,3) constructs a list [1,2,3].
   * @param init an array containing the numbers for the set
   */
  public IntSet(int... init) {
    this();
    for(int x : init)add(x);// complete the implementation for this constructor
  }
    
  ////////////////////////////////////////////////////////////////////    
  /**
   * Returns a string representation of the set.
   * @return a string representation of the set
   */ 
  public String toString() { 
    // We will represent a set {1,2,3} as [1,2,3] 
    // revise and complete the following code
    if (n==0) return "[]";
    String ans = "[" + head.val;
    for (Node nd = head.next; nd != null; nd = nd.next) 
      ans = ans + "," + nd.val;
    return ans + "]";
  }
  
    /**
   * Remove the element x from this set if x is a member of the set
   * return true
   * otherwise do nothing and return false
   * @param x the value to be removed from the set
   * @return the element removed 
   */
  public boolean remove(int p) {
    Node Q=head;
    if(Q.val==0)return false;
    if(Q.val==p){
      head = head.next;
      n--;
      return true;}
    return false;
  } 
  
  ////////////////////////////////////////////////////////////////////  
  /** Returns the number of elements of this set
    * @return the number of elements of this set
    */
  public int size() {
    return n;
  }
  
  ////////////////////////////////////////////////////////////////////  
  /** 
   * Add a Node with value x to the set 
   * @return true if x is not a member. Otherwise, returns false
   * @param x the value of the element to be added to the set.
   *
   */
  public boolean add(int x) {
   // revise complete the implementation 
   Node u = new Node(x,null);
    if (n == 0) { head = u; } 
     else       { tail.next = u; }
    tail = u;
    n++;
    return true;
  }
 

  ////////////////////////////////////////////////////////////////////  
  /**
   * Determines if i is a member of this set
   * @param i an integer 
   * @return true if i is a member of this set. Otherwise returns false 
   */
  public boolean contains(int i) {
    // revise and complete this code
   if(n==0)return false;
   Node W =head;
   for (int q=0;q<n;q++){
     if (W.val==i)return true;
       W=W.next;}
   return false;
  }
  
  ////////////////////////////////////////////////////////////////////    
  /**
   * Tests if the set is empty.
   * @return true iff the set is the empty set
   */
  public boolean isEmpty() {
    return (n==0);
  }
 ////////////////////////////////////////////////////////////////////  
  /**
   * A function to test if this set equals to set A. Two sets are equal
   * if they contains exactly the same collection of elements
   * @param A an IntSet
   * @return true if this set equals to set A, otherwise returns false
   * 
   */
  public boolean equals (IntSet A){
    if(this.size()!=A.size()) return false;
    Node Q=head;
    for(int i=0;i<A.size();i++){
      if(!contains(Q.val)) return true;
    Q=Q.next;
    }
   return true;
    
  }
  ////////////////////////////////////////////////////////////////////  
  /**
   * A static function for the class to compute the union of two sets
   * @param A IntSet
   * @param B IntSet
   * @return the union of set A and B (A, B are two IntSets)
   */
  public static IntSet union (IntSet A, IntSet B){
IntSet C = new IntSet();
if(A.size()!=0){
  Node Q=A.head;
  for(int i=0;i<A.size();i++){
    C.add(Q.val);
    Q=Q.next;
  }
  if(B.size()!=0){
    Node W=B.head;
    for (int w=0;w<B.size();w++){
      if (!A.contains(W.val))
        C.add(W.val);
      W=W.next;
    }
  }}
return C;
  }
  
 
  public static void main (String [] argv){
  }
}
