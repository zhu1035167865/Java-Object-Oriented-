import java.util.Arrays;
import java.util.Scanner;

public class HW02 {
  //////////////////////////////////////////////////////////
  // compute Leonardo numbers iteratively
  
  public static int leonardoIter(int n) {
    while(n>=2)
    { return (leonardoIter(n - 1) + leonardoIter(n - 2) + 1);}
     return 1;
  }//FIX ME!!!
  
    
  //////////////////////////////////////////////////////////
  // compute Leonardo numbers recursively
  public static int leonardoRec(int n) {
       if (n == 0 || n == 1)
            return 1;
        return (leonardoRec(n - 1) + leonardoRec(n - 2) + 1); // FIX ME!!!
  } 
  
  //////////////////////////////////////////////////////////////////////
  // compute the suits and the ranks of playing cards
  public static String suitOf(int n) {
      String suitNames [] = {"Diamonds","Clubs","Hearts","Spades"};
    if(n%4==0||n==0){
      System.out.print(suitNames[0]);
    }
    else if((n-1)%4==0||n==1){
    System.out.print(suitNames[1]);
    }
    else if((n-2)%4==0||n==2){
      System.out.print(suitNames[2]);
    }
    else if((n-3)%4==0||n==3){
    System.out.print(suitNames[3]);
    }
    return suitNames[0];  // replace the code by a correct implementation 
  }
  
   public static String rankOf(int n) {
   String rankNames[] = {"Ace", "Two", "Three", "Four", "Five", "Six",
    "Seven", "Eight", "Nine", "Ten", "Jack", "Queen","King"};
   int q;
   if((n-1)%13==0||n==0){
     System.out.println(rankNames[0]);
   }
  else if((n-2)%13==0||n==1){
     System.out.println(rankNames[1]);
   }
  else if((n-3)%13==0||n==2){
     System.out.println(rankNames[2]);
   }
  else if((n-4)%13==0||n==3){
     System.out.println(rankNames[3]);
  }
  else if((n-5)%13==0||n==4){
     System.out.println(rankNames[4]);
   }
  else if((n-6)%13==0||n==5){
     System.out.println(rankNames[5]);
   }
  else if((n-7)%13==0||n==6){
     System.out.println(rankNames[6]);
   }
  else if((n-8)%13==0||n==7){
     System.out.println(rankNames[7]);
   }
  else if((n-9)%13==0||n==8){
    System.out.println(rankNames[8]);
   }
  else if((n-10)%13==0||n==9){
     System.out.println(rankNames[9]);
   }
  else if((n-11)%13==0||n==10){
     System.out.println(rankNames[10]);
   }
  else if((n-12)%13==0||n==11){
     System.out.println(rankNames[11]);
   }
  else if((n-13)%13==0||n==12){
     System.out.println(rankNames[12]);
   }

    return rankNames[0]; // replace the code by a correct implementation 
  }
  //////////////////////////////////////////////////////////////////////
  // compute the solution to a quadratic equation: ax^2 + bx + c = 0
  public static double quadSol(double a, double b, double c) { 
     double d = b * b - 4 * a * c;
        if(d > 0)
        {
            System.out.println("Roots are real and unequal");
            double root1 = ( - b + Math.sqrt(d))/(2*a);
            double root2 = (-b - Math.sqrt(d))/(2*a);
            if(root1>=root2){
            System.out.println("Large  root is:"+root1);
            }
            else{
            System.out.println("large  root is:"+root2);
            }
        }
        else if(d == 0)
        {
            System.out.println("Roots are real and equal");
            double root1 = (-b+Math.sqrt(d))/(2*a);
            System.out.println("Root:"+root1);
        }
        else
        {
            System.out.println("Roots are imaginary");
        } // replace the code by a correct implementation 
        return 0;
    }
    
//////////////////////////////////////////////////////
  // reverse an integer and show the results as a String
  public static int reverse(int n) {
   int rev_num = 0; 
    while (n != 0) 
    { 
        rev_num = rev_num*10 + n%10; 
        n = n/10; 
    } 
    return rev_num; // replace the code by a correct implementation 
  }
 
  
  
  
 
  
  //////////////////////////////////////////////////////////
  /**
   * The main method for testing the assignment's methods.
   */
  public static void main(String argv[]) {
    
    /////////////////////////////////////////////////////////
    System.out.println("\n**Tests for Problem 1**");
    for (int i = 0; i<=9; i++) 
      System.out.println("leonardoIter("+i+") =\t"+ leonardoIter(i));
    
    /////////////////////////////////////////////////////////
    System.out.println("\n**Tests for Problem 2**");
    for (int i = 0; i<=9; i++) 
      System.out.println("leonardoRec("+i+") =\t"+ leonardoRec(i));
    
    /////////////////////////////////////////////////////////
    System.out.println("\n**Tests for Problem 3**");
    
    runTest3();
   
    
    /////////////////////////////////////////////////////////
    System.out.println("\n**Tests for Problem 4**");
    double a, b, c;
        double root1, root2, d;
        Scanner s = new Scanner(System.in);
        System.out.println("Given quadratic equation:ax^2 + bx + c");
        System.out.print("Enter a:");
        a = s.nextDouble();
        System.out.print("Enter b:");
        b = s.nextDouble();
        System.out.print("Enter c:");
        c = s.nextDouble();
        System.out.println("Given quadratic equation:"+a+"x^2 + "+b+"x + "+c);
        quadSol(a,b,c);
 
    // Print the largest solution to the following quadratic equations
    // x^2 - x - 1
    // 6 x^2 - x - 1
    // 10 x^2 - 4 x - 3
    // x^2 - 3 x - 4
    
    /////////////////////////////////////////////////////////
    System.out.println("\n**Tests for Problem 5**");
    int t;
    Scanner q = new Scanner(System.in);
        System.out.print("Enter number:");
        t = s.nextInt();
    System.out.println(reverse(t));
    // Print the reverse of the following integers
    // 13244
    // 1357431
    // -184590
    // 0
  }                                
  

 //////////////////////////////////////////////////////////
  // A little method for performing tests for problem 3.
  public static void runTest3() {
    // FIX ME!!  Your code must correctly handle tense
    //           (past, present, future); this code does not.
    int hand1 [] ={17, 23, 5, 19};
    int hand2 [] ={6, 26, 40, 2, 12};
    int hand3 [] ={33, 16, 50};
    int hand4 [] ={9, 11, 36, 42};
    int count1=0;
    int count2=0;
    int count3=0;
    int count4=0;
    System.out.println("hand1 consists for the following cards");
    int q=0;
    while(q<=3){
    System.out.print(" "+hand1[q]+"  "); // replace the code by a correct implementation
     suitOf(hand1[q]);
     System.out.print("  ");
     rankOf(hand1[q]+1);
     if((hand1[q]+1)%13==0){
     count1++;}
     if((hand1[q]-3)%4==0||hand1[q]==3){
       count2++;}
      if(hand1[q]>=4-1&&hand1[q]<=8-1||hand1[q]>=17-1&&hand1[q]<=21-1||hand1[q]>=30-1&&hand1[q]<=34-1||hand1[q]>=43-1&&hand1[q]<=47-1){
      count3++;}
      if(hand1[q]>=11-1&&hand1[q]<=13-1||hand1[q]>=24-1&&hand1[q]<=26-1||hand1[q]>=37-1&&hand1[q]<=39-1||hand1[q]>=50-1&&hand1[q]<=52-1){
      count4++;}
     q++;
     }
    System.out.println("hand2 consists for the following cards");
 int w=0;
    while(w<=4){
    System.out.print(" "+hand2[w]+"  "); // replace the code by a correct implementation
     suitOf(hand2[w]);
     System.out.print("  ");
     rankOf(hand2[w]+1);
      if(hand2[w]%13==0){
        count1++;}
      if((hand2[w]-3)%4==0||hand2[w]==3){
       count2++;}
       if(hand2[w]>=4-1&&hand2[w]<=8-1||hand2[w]>=17-1&&hand2[w]<=21-1||hand2[w]>=30-1&&hand2[w]<=34-1||hand2[w]>=43-1&&hand2[w]<=47-1){
      count3++;}
        if(hand2[w]>=11-1&&hand2[w]<=13-1||hand2[w]>=24-1&&hand2[w]<=26-1||hand2[w]>=37-1&&hand2[w]<=39-1||hand2[w]>=50-1&&hand2[w]<=52-1){
      count4++;}
    w++;
    }
    System.out.println("hand3 consists for the following cards");
    int e=0;
    while(e<=2){
    System.out.print(" "+hand3[e]+"  "); // replace the code by a correct implementation
     suitOf(hand3[e]);
     System.out.print("  ");
     rankOf(hand3[e]+1);
      if(hand3[e]%13==0){
        count1++;}
      if((hand3[e]-3)%4==0||hand3[e]==3){
       count2++;}
      if(hand3[e]>=4-1&&hand3[e]<=8-1||hand3[e]>=17-1&&hand3[e]<=21-1||hand3[e]>=30-1&&hand3[e]<=34-1||hand3[e]>=43-1&&hand3[e]<=47-1){
      count3++;}
      if(hand3[e]>=11-1&&hand3[e]<=13-1||hand3[e]>=24-1&&hand3[e]<=26-1||hand3[e]>=37-1&&hand3[e]<=39-1||hand3[e]>=50-1&&hand3[e]<=52-1){
      count4++;}
    e++;
    }
    System.out.println("hand4 consists for the following cards");
    int r=0;
    while(r<=3){
    System.out.print(" "+hand4[r]+"  "); // replace the code by a correct implementation
     suitOf(hand4[r]);
     System.out.print("  ");
     rankOf(hand4[r]+1);
      if(hand4[r]%13==0){
        count1++;}
      if((hand4[r]-3)%4==0||hand4[r]==3){
       count2++;}
      if(hand4[r]>=4-1&&hand4[r]<=8-1||hand4[r]>=17-1&&hand4[r]<=21-1||hand4[r]>=30-1&&hand4[r]<=34-1||hand4[r]>=43-1&&hand4[r]<=47-1){
      count3++;}
       if(hand4[r]>=11-1&&hand4[r]<=13-1||hand4[r]>=24-1&&hand4[r]<=26-1||hand4[r]>=37-1&&hand4[r]<=39-1||hand4[r]>=50-1&&hand4[r]<=52-1){
      count4++;}
    r++;
    }
    System.out.println("Among all the cards in hand1 to hand4:");
    // replace the code below by a correct implementation to determine the answers required below
    System.out.println("the number of kings = "+count1);
    System.out.println("the number of spades ="+count2);
    System.out.println("the number of cards which have ranks between 4 to 8 (inclusive): "+count3);
    System.out.println("the number of cards that are face cards (i.e. jack, queen or king):"+count4);
  }   
   // You may add other methods/functions here to help your implementation
    }
  